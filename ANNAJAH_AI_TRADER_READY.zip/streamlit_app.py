import streamlit as st
import pandas as pd
import numpy as np
import yfinance as yf
import plotly.graph_objects as go
from datetime import datetime

st.set_page_config(page_title="ANNAJAH AI TRADER", page_icon="📈", layout="wide")

# ---------- Styling ----------
st.markdown("""
<style>
.main {background-color:#0b1220;}
.block-container {padding-top:1.5rem; padding-bottom:2rem;}
[data-testid="stMetric"] {background:#111c2e; border:1px solid #26364d; padding:14px; border-radius:12px;}
div[data-testid="stDataFrame"] {border:1px solid #26364d; border-radius:10px;}
</style>
""", unsafe_allow_html=True)

st.title("📈 ANNAJAH AI TRADER")
st.caption("Indonesia Stock Market • Technical scanner • Risk management")
st.warning("Analisis ini bersifat informasi, bukan rekomendasi investasi. Data Yahoo Finance dapat tertunda, tidak lengkap, atau gagal tersedia. Periksa harga dan kondisi pasar di sekuritas sebelum transaksi.")

DEFAULT_TICKERS = ["BBRI.JK", "BMRI.JK", "BBCA.JK", "ANTM.JK", "DSSA.JK", "TLKM.JK", "ASII.JK", "BRPT.JK", "ADRO.JK", "MDKA.JK"]

with st.sidebar:
    st.header("⚙️ Pengaturan")
    capital = st.number_input("Modal trading (Rp)", min_value=100000, value=50000000, step=1000000, format="%d")
    risk_pct = st.slider("Risiko maksimal per transaksi (%)", 0.25, 3.0, 1.0, 0.25)
    period = st.selectbox("Periode data", ["3mo", "6mo", "1y", "2y"], index=1)
    custom = st.text_input("Tambah kode saham (pisahkan koma)", placeholder="UNTR, ICBP, GOTO")
    run_scan = st.button("🔄 Jalankan scanner", type="primary", use_container_width=True)
    st.caption("Contoh kode: DSSA atau DSSA.JK")

def normalize_ticker(t):
    t = t.strip().upper()
    if not t:
        return ""
    return t if "." in t else t + ".JK"

def get_history(ticker, period):
    try:
        df = yf.download(ticker, period=period, interval="1d", auto_adjust=True, progress=False, threads=False)
        if df is None or df.empty:
            return None
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)
        needed = ["Close", "High", "Low", "Volume"]
        if not all(c in df.columns for c in needed):
            return None
        df = df[needed].dropna()
        return df if len(df) >= 30 else None
    except Exception:
        return None

def indicators(df):
    x = df.copy()
    close = x["Close"]
    x["EMA20"] = close.ewm(span=20, adjust=False).mean()
    x["EMA50"] = close.ewm(span=50, adjust=False).mean()
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    rs = gain / loss.replace(0, np.nan)
    x["RSI"] = 100 - (100 / (1 + rs))
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    x["MACD"] = ema12 - ema26
    x["MACD_signal"] = x["MACD"].ewm(span=9, adjust=False).mean()
    tr = pd.concat([
        x["High"] - x["Low"],
        (x["High"] - close.shift()).abs(),
        (x["Low"] - close.shift()).abs()
    ], axis=1).max(axis=1)
    x["ATR"] = tr.rolling(14).mean()
    return x.dropna()

def analyze(ticker, period):
    raw = get_history(ticker, period)
    if raw is None:
        return None, "Data tidak tersedia"
    x = indicators(raw)
    if x.empty:
        return None, "Data indikator belum cukup"
    last = x.iloc[-1]
    prev = x.iloc[-2]
    score = 0
    score += 1 if last["Close"] > last["EMA20"] else -1
    score += 1 if last["EMA20"] > last["EMA50"] else -1
    score += 1 if last["MACD"] > last["MACD_signal"] else -1
    score += 1 if last["RSI"] >= 50 else -1
    if score >= 2:
        signal = "BUY"
    elif score <= -2:
        signal = "SELL"
    else:
        signal = "HOLD"
    price = float(last["Close"])
    atr = float(last["ATR"]) if pd.notna(last["ATR"]) else price * 0.03
    stop = max(0, price - 1.5 * atr)
    target = price + 2.0 * atr
    change = (price / float(prev["Close"]) - 1) * 100
    risk_money = capital * risk_pct / 100
    risk_per_share = max(price - stop, 1)
    shares = int(risk_money // risk_per_share)
    # Indonesian stock lot = 100 shares
    lots = max(0, shares // 100)
    result = {
        "Kode": ticker.replace(".JK", ""),
        "Harga": price,
        "Perubahan harian": change,
        "RSI": float(last["RSI"]),
        "Sinyal": signal,
        "Entry acuan": price,
        "Stop loss": stop,
        "Target 1": target,
        "Estimasi lot": lots,
        "Tanggal data": x.index[-1].strftime("%d-%m-%Y")
    }
    return (x, result), None

tickers = DEFAULT_TICKERS.copy()
if custom.strip():
    tickers += [normalize_ticker(v) for v in custom.split(",") if v.strip()]
tickers = list(dict.fromkeys(tickers))

if "scan_results" not in st.session_state or run_scan:
    rows, histories, errors = [], {}, []
    progress = st.progress(0, text="Mengambil data saham…")
    for i, ticker in enumerate(tickers):
        item, err = analyze(ticker, period)
        if item:
            hist, row = item
            rows.append(row)
            histories[row["Kode"]] = hist
        else:
            errors.append(f"{ticker}: {err}")
        progress.progress((i + 1) / len(tickers), text=f"Memeriksa {ticker}…")
    progress.empty()
    st.session_state.scan_results = pd.DataFrame(rows)
    st.session_state.histories = histories
    st.session_state.errors = errors

results = st.session_state.scan_results
histories = st.session_state.histories

if results.empty:
    st.error("Belum ada data saham yang berhasil diambil. Coba tekan Jalankan scanner lagi atau periksa koneksi internet.")
    if st.session_state.errors:
        st.write("\n".join(st.session_state.errors))
    st.stop()

buy_count = int((results["Sinyal"] == "BUY").sum())
hold_count = int((results["Sinyal"] == "HOLD").sum())
sell_count = int((results["Sinyal"] == "SELL").sum())

c1, c2, c3, c4 = st.columns(4)
c1.metric("Modal trading", f"Rp{capital:,.0f}".replace(",", "."))
c2.metric("Sinyal BUY", buy_count)
c3.metric("Sinyal HOLD", hold_count)
c4.metric("Sinyal SELL", sell_count)

st.subheader("🔎 Stock Scanner")
display = results.copy()
for col in ["Harga", "Entry acuan", "Stop loss", "Target 1"]:
    display[col] = display[col].map(lambda v: f"Rp{v:,.0f}".replace(",", "."))
display["Perubahan harian"] = display["Perubahan harian"].map(lambda v: f"{v:+.2f}%")
display["RSI"] = display["RSI"].map(lambda v: f"{v:.1f}")
st.dataframe(display, use_container_width=True, hide_index=True)

st.subheader("📊 Detail saham")
selected = st.selectbox("Pilih saham", list(histories.keys()))
df = histories[selected]
latest = df.iloc[-1]
fig = go.Figure()
fig.add_trace(go.Scatter(
    x=df.index, y=df["Close"], name="Harga penutupan",
    line=dict(width=2)
))
fig.add_trace(go.Scatter(x=df.index, y=df["EMA20"], name="EMA 20", line=dict(width=1.5)))
fig.add_trace(go.Scatter(x=df.index, y=df["EMA50"], name="EMA 50", line=dict(width=1.5)))
fig.update_layout(height=480, template="plotly_dark", xaxis_rangeslider_visible=False,
                  title=f"{selected} • Harga & Moving Average", margin=dict(l=10,r=10,t=50,b=10))
st.plotly_chart(fig, use_container_width=True)

m1, m2, m3, m4 = st.columns(4)
m1.metric("Harga terakhir", f"Rp{latest['Close']:,.0f}".replace(",", "."))
m2.metric("RSI 14", f"{latest['RSI']:.1f}")
m3.metric("MACD", f"{latest['MACD']:.2f}")
m4.metric("ATR 14", f"{latest['ATR']:.2f}")

row = results[results["Kode"] == selected].iloc[0]
st.markdown(f"""
**Sinyal teknikal:** `{row['Sinyal']}`

- Entry acuan: **Rp{row['Entry acuan']:,.0f}**
- Stop loss indikatif: **Rp{row['Stop loss']:,.0f}**
- Target indikatif: **Rp{row['Target 1']:,.0f}**
- Estimasi ukuran posisi: **{row['Estimasi lot']} lot** berdasarkan risiko {risk_pct:.2f}% dari modal.
""".replace(",", "."))

with st.expander("Cara membaca sinyal"):
    st.write("""
    - **BUY:** minimal 2 dari 4 kondisi teknikal mendukung tren positif.
    - **SELL:** minimal 2 dari 4 kondisi teknikal menunjukkan tekanan negatif.
    - **HOLD:** sinyal campuran, belum ada konfirmasi kuat.
    - Kondisi yang dinilai: harga vs EMA20, EMA20 vs EMA50, MACD vs garis sinyal, dan RSI di atas/bawah 50.
    - Entry, stop loss, target, dan estimasi lot adalah perhitungan teknikal sederhana, bukan kepastian hasil.
    """)

if st.session_state.errors:
    with st.expander("Saham yang datanya tidak tersedia"):
        st.write("\n".join(st.session_state.errors))

st.caption(f"Terakhir diproses: {datetime.now().strftime('%d-%m-%Y %H:%M:%S')} • Data harian, bukan streaming tick real-time.")
