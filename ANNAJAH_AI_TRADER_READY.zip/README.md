# ANNAJAH AI TRADER

Aplikasi dashboard analisis teknikal saham Indonesia berbasis Streamlit.

## Isi paket
- `streamlit_app.py` — aplikasi utama
- `requirements.txt` — daftar library yang diperlukan

## Cara menjalankan di Streamlit Community Cloud
1. Upload kedua file ke folder utama (root) repository GitHub.
2. Pastikan `requirements.txt` adalah FILE, bukan folder.
3. Buka https://share.streamlit.io/
4. Pilih **New app** lalu pilih repository, branch `main`, dan Main file path `streamlit_app.py`.
5. Tekan **Deploy**.

## Catatan data
Aplikasi mengambil data historis harian dari Yahoo Finance menggunakan kode saham berakhiran `.JK`.
Ketersediaan dan keterlambatan data mengikuti Yahoo Finance. Data bukan streaming real-time dan tidak dijamin selalu tersedia.

## Peringatan risiko
Sinyal BUY/SELL/HOLD dan level harga adalah hasil aturan teknikal sederhana untuk membantu analisis, bukan rekomendasi investasi atau jaminan keuntungan. Selalu verifikasi data dan gunakan manajemen risiko.
