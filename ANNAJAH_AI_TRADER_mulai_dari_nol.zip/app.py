import streamlit as st
import pandas as pd
import yfinance as yf

st.set_page_config(page_title="ANNAJAH AI TRADER", page_icon="📈", layout="wide")
st.title("📈 ANNAJAH AI TRADER")
st.caption("Scanner saham BEI • Analisis teknikal berbasis aturan")
st.warning("Mode analisis saja. Data Yahoo Finance dapat terlambat/tidak lengkap. Tidak ada transaksi otomatis.")

with st.sidebar:
    st.header("Pengaturan")
    modal = st.number_input("Modal simulasi (Rp)", min_value=1000000, value=50000000, step=1000000)
    risiko = st.number_input("Risiko per transaksi (Rp)", min_value=10000, value=250000, step=10000)
    batas_harian = st.number_input("Batas rugi harian (Rp)", min_value=10000, value=500000, step=10000)
    tickers = st.text_input("Ticker BEI (pisahkan koma)", "BBRI, BMRI, BBCA, ANTM")
    period = st.selectbox("Periode data", ["3mo", "6mo", "1y", "2y"], index=1)

def rupiah(n):
    return "Rp" + f"{n:,.0f}".replace(",", ".")

c1, c2, c3 = st.columns(3)
c1.metric("Modal simulasi", rupiah(modal))
c2.metric("Risiko/transaksi", rupiah(risiko))
c3.metric("Batas rugi harian", rupiah(batas_harian))

def scan(symbol):
    code = symbol.strip().upper()
    data = yf.download(code if "." in code else code + ".JK", period=period, interval="1d", auto_adjust=True, progress=False)
    if data.empty or len(data) < 55:
        raise ValueError("Data kosong atau belum cukup")
    close, volume = data["Close"], data["Volume"]
    if isinstance(close, pd.DataFrame): close = close.iloc[:, 0]
    if isinstance(volume, pd.DataFrame): volume = volume.iloc[:, 0]
    df = pd.DataFrame({"Close": close, "Volume": volume}).dropna()
    df["EMA20"] = df.Close.ewm(span=20, adjust=False).mean()
    df["EMA50"] = df.Close.ewm(span=50, adjust=False).mean()
    delta = df.Close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    rs = gain / loss.replace(0, float("nan"))
    df["RSI14"] = 100 - 100 / (1 + rs)
    df["VolRatio"] = df.Volume / df.Volume.rolling(20).mean()
    last, prev = df.iloc[-1], df.iloc[-2]
    score = int(last.Close > last.EMA20) + int(last.EMA20 > last.EMA50) + int(last.RSI14 >= 50) + int(last.VolRatio >= 1)
    signal = "BUY (pantau)" if score >= 3 else ("WAIT" if score == 2 else "SELL / hindari")
    row = {"Saham": code, "Harga": float(last.Close), "Perubahan %": float((last.Close / prev.Close - 1) * 100),
           "RSI 14": float(last.RSI14), "Volume x": float(last.VolRatio), "Sinyal": signal,
           "Tanggal": df.index[-1].strftime("%d-%m-%Y")}
    return df, row

st.subheader("Stock Scanner")
if st.button("Jalankan Scanner", type="primary", use_container_width=True):
    rows, charts, errors = [], {}, []
    with st.spinner("Mengambil data saham..."):
        for symbol in [x.strip() for x in tickers.split(",") if x.strip()]:
            try:
                df, row = scan(symbol)
                rows.append(row)
                charts[symbol.upper()] = df
            except Exception as e:
                errors.append(f"{symbol}: {e}")
    if rows:
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        selected = st.selectbox("Grafik saham", list(charts.keys()))
        st.line_chart(charts[selected][["Close", "EMA20", "EMA50"]])
    for error in errors:
        st.info(error)
else:
    st.info("Tekan Jalankan Scanner. Contoh ticker: BBRI, BMRI, BBCA, ANTM.")

st.subheader("Kalkulator Ukuran Posisi")
a, b = st.columns(2)
entry = a.number_input("Harga beli rencana (Rp)", min_value=1.0, value=1000.0, step=10.0)
stop = b.number_input("Harga stop loss (Rp)", min_value=0.0, value=970.0, step=10.0)
if entry > stop:
    lots = min(int(risiko // ((entry-stop)*100)), int(modal // (entry*100)))
    st.success(f"Maksimal simulasi: {lots:,} lot • Nilai beli: {rupiah(lots*100*entry)} • Risiko ke stop loss: {rupiah(lots*100*(entry-stop))}")
else:
    st.error("Harga beli harus lebih tinggi daripada stop loss.")
st.caption("Indikator: EMA20/EMA50, RSI14, volume. Alat bantu edukasi, bukan prediksi pasti atau auto-trading.")
